<p>
  <?php
  if (isset($form['mailchimp_lists']['mailchimp_newsletter']['title'])):
    print $form['mailchimp_lists']['mailchimp_newsletter']['title']['#description'];
  endif;
  ?>
  <?php
  if (isset($form['mailchimp_lists']['mailchimp_newsletter']['subscribe'])):
    print $form['mailchimp_lists']['mailchimp_newsletter']['subscribe']['#description'];
  endif;
  ?>
</p>
<div class="control-group">
  <div class="input-append">
    <?php
    if (isset($form['mailchimp_lists']['mailchimp_newsletter']['mergevars']['EMAIL'])):
      print drupal_render($form['mailchimp_lists']['mailchimp_newsletter']['mergevars']['EMAIL']);
    endif;
    ?>
    <?php print drupal_render($form['submit']); ?>
  </div>
</div>
<?php
print render($form['form_id']);
print render($form['form_build_id']);
print render($form['form_token']);
?>
