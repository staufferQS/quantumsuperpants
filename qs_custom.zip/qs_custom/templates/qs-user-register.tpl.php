<?php print drupal_render($form['field_first_name']); ?>
<?php print drupal_render($form['field_last_name']); ?>
<?php //print drupal_render($form['profile_main']['field_username_adjective']);     ?>
<?php print drupal_render($form['account']['name']); ?>
<?php print drupal_render($form['account']['mail']); ?>
<?php print drupal_render($form['account']['field_e_email_confirm']); ?>
<?php print drupal_render($form['account']['pass']); ?>
<?php print drupal_render($form['field_age']); ?>
<?php print drupal_render($form['field_phone_number']); ?>
<?php print drupal_render($form['field_state_provice']); ?>
<?php print drupal_render($form['captcha']); ?>
<?php print drupal_render($form['mailchimp_lists']); ?>
<?php print drupal_render($form['field_i_have_read_and_accept_the']); ?>

<?php print drupal_render($form['actions']); ?>
<?php

print render($form['form_id']);
print render($form['form_build_id']);
print render($form['form_token']);
?>
