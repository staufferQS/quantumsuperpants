<h2><strong>Rockstars</strong> wanted!</h2>

<div class="row">
	<div class="span12">
		<p class="lead">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla non pulvinar. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu risus enim, ut pulvinar lectus. Sed hendrerit nibh metus.
		</p>
	</div>
</div>

<hr>

<div class="row">
	<div class="span8">

		<section class="toggle">
			<label>Technical Support Representative</label>
			<div class="toggle-content">
				<p><strong>Location:</strong> New York - <strong>Department:</strong> Engineering</p>
				<p>Mauris elit velit, lobortis sed interdum at, vestibulum vitae libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque iaculis ligula ut ipsum mattis viverra. </p>
				<p><a class="btn btn-primary pull-bottom" href="#">Apply Now</a></p>
			</div>
		</section>
		<section class="toggle">
			<label>Copywriter</label>
			<div class="toggle-content">
				<p><strong>Location:</strong> New York - <strong>Department:</strong> Engineering</p>
				<p>Mauris elit velit, lobortis sed interdum at, vestibulum vitae libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque iaculis ligula ut ipsum mattis viverra. </p>
				<p><a class="btn btn-primary pull-bottom" href="#">Apply Now</a></p>
			</div>
		</section>
		<section class="toggle">
			<label>Customer Care Specialist</label>
			<div class="toggle-content">
				<p><strong>Location:</strong> New York - <strong>Department:</strong> Engineering</p>
				<p>Mauris elit velit, lobortis sed interdum at, vestibulum vitae libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque iaculis ligula ut ipsum mattis viverra. </p>
				<p><a class="btn btn-primary pull-bottom" href="#">Apply Now</a></p>
			</div>
		</section>
		<section class="toggle">
			<label>Interactive Art Director</label>
			<div class="toggle-content">
				<p><strong>Location:</strong> New York - <strong>Department:</strong> Engineering</p>
				<p>Mauris elit velit, lobortis sed interdum at, vestibulum vitae libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque iaculis ligula ut ipsum mattis viverra. </p>
				<p><a class="btn btn-primary pull-bottom" href="#">Apply Now</a></p>
			</div>
		</section>
		<section class="toggle">
			<label>Mobile Developer</label>
			<div class="toggle-content">
				<p><strong>Location:</strong> New York - <strong>Department:</strong> Engineering</p>
				<p>Mauris elit velit, lobortis sed interdum at, vestibulum vitae libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque iaculis ligula ut ipsum mattis viverra. </p>
				<p><a class="btn btn-primary pull-bottom" href="#">Apply Now</a></p>
			</div>
		</section>
		<section class="toggle">
			<label>Technical Support Representative</label>
			<div class="toggle-content">
				<p><strong>Location:</strong> New York - <strong>Department:</strong> Engineering</p>
				<p>Mauris elit velit, lobortis sed interdum at, vestibulum vitae libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque iaculis ligula ut ipsum mattis viverra. </p>
				<p><a class="btn btn-primary pull-bottom" href="#">Apply Now</a></p>
			</div>
		</section>
		<section class="toggle">
			<label>Copywriter</label>
			<div class="toggle-content">
				<p><strong>Location:</strong> New York - <strong>Department:</strong> Engineering</p>
				<p>Mauris elit velit, lobortis sed interdum at, vestibulum vitae libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque iaculis ligula ut ipsum mattis viverra. </p>
				<p><a class="btn btn-primary pull-bottom" href="#">Apply Now</a></p>
			</div>
		</section>
		<section class="toggle">
			<label>Customer Care Specialist</label>
			<div class="toggle-content">
				<p><strong>Location:</strong> New York - <strong>Department:</strong> Engineering</p>
				<p>Mauris elit velit, lobortis sed interdum at, vestibulum vitae libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque iaculis ligula ut ipsum mattis viverra. </p>
				<p><a class="btn btn-primary pull-bottom" href="#">Apply Now</a></p>
			</div>
		</section>

	</div>
	<div class="span4">
		<div class="featured-box featured-box-secundary">
			<div class="box-content clearfix">
				<h4>The Benefits</h4>
				<ul class="flickr-feed"></ul>

				<hr />

				<ul class="list icons unstyled pull-left">
					<li><i class="icon-ok"></i>Fusce sit quis arcu vestibulum.</li>
					<li><i class="icon-ok"></i>Fusce sit amet orci quis arcu vestibulum.</li>
					<li><i class="icon-ok"></i>Fusce sit amet orci quis arcu.</li>
					<li><i class="icon-ok"></i>Fusce sit amet orci arcu vestibu.</li>
					<li><i class="icon-ok"></i>Fusce sit orci quis arcu vestibulum.</li>
				</ul>

			</div>
		</div>
	</div>
</div>
<script>
	jQuery(document).ready(function ($) {
		$('ul.flickr-feed').jflickrfeed({
			limit: 6,
			qstrings: {
				id: '93691989@N03'
			},
     itemTemplate: '<li><a rel="flickr[pp_gal]" href="{{image_b}}" class="fancybox"><span class="thumbnail"><img alt="{{title}}" src="{{image_s}}" /></span></a></li>'
	  });
	});
</script>