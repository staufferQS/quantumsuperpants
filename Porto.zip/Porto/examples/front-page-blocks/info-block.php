<div class="container">
<div class="row center">
	<div class="span12">
		<h2 class="short">Porto is <strong class="inverted">incredibly</strong> beautiful and fully responsive.</h2>
		<p class="featured lead">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce elementum, nulla vel pellentesque consequat, ante nulla hendrerit arcu, ac tincidunt mauris lacus sed leo. vamus suscipit molestie vestibulum.
		</p>
	</div>
</div>
</div>