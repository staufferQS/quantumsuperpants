<div class="home-intro">
	<div class="container">

		<div class="row">
			<div class="span8">
				<p>
					The fastest way to grow your business with the leader in <em>Technology.</em>
					<span>Check out our options and features included.</span>
				</p>
			</div>
			<div class="span4">
				<div class="get-started">
					<a href="#" class="btn btn-large btn-primary">Get Started Now!</a>
					<div class="learn-more">or <a href="index.html">learn more.</a></div>
				</div>
			</div>
		</div>

	</div>
</div>