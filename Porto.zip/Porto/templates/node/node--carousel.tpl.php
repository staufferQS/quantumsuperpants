<?php

/**
 * @file node--faq.tpl.php
 * Porto's node template for the FAQ content type.
 */
?>

<?php print render($content['field_image']); ?>