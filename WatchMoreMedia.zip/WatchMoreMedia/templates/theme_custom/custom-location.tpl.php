<div class="location vcard">
  <div class="adr">
    <?php if (!empty($street)): ?>
      <div class="street-address">
        <span class='location-label'> <?php print $street_label; ?>:</span>
        <span class='location-content'> <?php print $street; ?> </span>
      </div>
    <?php endif; ?>
    <?php if (!empty($additional)): ?>
      <div class="additional">
        <span class='location-label'> <?php print $additional_label; ?>:</span>
        <span class='location-content'> <?php print $additional; ?> </span>
      </div>
    <?php endif; ?>
    <?php if (!empty($city)): ?>
      <div class="city">
        <span class='location-label'> <?php print $city_label; ?>:</span>
        <span class='location-content'> <?php print $city; ?> </span>
      </div>
    <?php endif; ?>
    <?php if (!empty($province)): ?>
      <div class="province">
        <span class='location-label'> <?php print $province_label; ?>:</span>
        <span class='location-content'> <?php print $province; ?> </span>
      </div>
    <?php endif; ?>
    <?php if (!empty($postal_code)): ?>
      <div class="postal-code">
        <span class='location-label'> <?php print $postal_code_label; ?>:</span>
        <span class='location-content'> <?php print $postal_code; ?> </span>
      </div>
    <?php endif; ?>
    <?php if (!empty($country_name)): ?>
      <div class="country-name">
        <span class='location-label'> <?php print $country_name_label; ?>:</span>
        <span class='location-content'> <?php print $country_name; ?> </span>
      </div>
    <?php endif; ?>
    <?php if (!empty($email)): ?>
      <div class="email">
        <span class='location-label'> <?php print $email_label; ?>:</span>
        <span class='location-content'> <a href="mailto:<?php print $email; ?>"><?php print $email; ?></a></span>
      </div>
    <?php endif; ?>
    <?php if (!empty($phone)): ?>
      <div class="tel">
        <span class='location-label'> <?php print $phone_label; ?>:</span>
        <span class='location-content'> <?php print $phone; ?> </span>
      </div>
    <?php endif; ?>
    <?php if (!empty($fax)): ?>
      <div class="tel">
        <span class='location-label'> <?php print $fax_label; ?>:</span>
        <span class='location-content'> <?php print $fax; ?> </span>
      </div>
    <?php endif; ?>
    <?php if (isset($latitude) && isset($longitude)): ?>
      <?php // Assume that 0, 0 is invalid. ?>
      <?php if ($latitude != 0 || $longitude != 0): ?>
        <span class="geo"><abbr class="latitude" title="<?php print $latitude; ?>"><?php print $latitude_dms; ?></abbr>, <abbr
            class="longitude" title="<?php print $longitude; ?>"><?php print $longitude_dms; ?></abbr></span>
        <?php endif; ?>
      <?php endif; ?>
  </div>
  <?php if (!empty($map_link)): ?>
    <div class="map-link"><?php print $map_link; ?></div>
  <?php endif; ?>
</div>
