<div id="node-<?php print $node->nid; ?>" class="container">
  <div id="video-detail" class="row">
    <div class="span9">
      <div class="node-video-title">
        <span class="field-content">
          <a href="<?php print $node_url; ?>"><?php print $title; ?></a>
        </span>
      </div>
      <div class="node-video-field-embed">
        <?php print isset($video) ? $video : ''; ?>
      </div>
      <div class="tabs-wrapper">
        <div class="tab-buttons">
          <ul>
            <li class="active"><span><?php print t('INFO'); ?></span></li>
            <li><span><?php print t('SHARE'); ?></span></li>
            <li><span><?php print t('Credits'); ?></span></li>
          </ul>
        </div>
        <div class="tab-container">
          <div class="tab-content active">
            <p>
              <strong>
                <?php print t('Published') . ' '; ?>
                <?php print date('M d, Y', $node->created); ?>
              </strong>
            </p>
            <div class="description">
              <?php print render($content['body']); ?>
              <ul class="list-other-info">
                <li><?php print render($content['views']); ?></li>
                <li><?php print render($content['field_rating']); ?></li>
                <li><?php print render($content['field_categories']); ?></li>
                <li><?php print render($content['field_keyword']); ?></li>
              </ul>
            </div>
          </div>
          <div class="tab-content hid">
            <?php print !empty($content['field_addthis']) ? render($content['field_addthis']) : ''; ?>
            <input id="share_url" value="<?php print $GLOBALS['base_url'] . $node_url; ?>" name="share_url" onClick="this.select();">
          </div>
          <div class="tab-content hid">
            <?php print render($content['field_credit']); ?>
          </div>
        </div>
      </div>
      <div class="like-favorite-block">
        <?php
          print render($content['rate_like']);
          global $user;
          if (!$user->uid) {
            print '<span class="flag-wrapper">' . l(t('Add to favorites'), 'user/login') . '</span>';
          } else {
            print render($content['favorites']);
          }
        ?>
      </div>
    </div>
  </div>
</div>
<div class="container">
  <div class="video-playlist" class="row">
    <div class="row">
      <div class="span9">
        <?php print render($content['view_detail']); ?>
      </div>
    </div>
  </div>
</div>
