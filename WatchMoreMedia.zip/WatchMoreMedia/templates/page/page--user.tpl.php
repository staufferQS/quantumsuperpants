<div class="body">
  <header id="header">
    <div class="container">
      <?php if ($logo): ?>
        <div class="logo">
		      <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" id="logo">
		        <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
		      </a>
        </div>
	    <?php endif; ?>
      <?php if ($block_ads): ?>
        <div class="block-ads">
          <?php print $block_ads; ?>
        </div>
      <?php endif; ?>
	    <?php if ($site_name || $site_slogan): ?>
	      <div id="name-and-slogan"<?php if ($disable_site_name && $disable_site_slogan) { print ' class="hidden"'; } ?>>
	        <?php if ($site_name): ?>
	          <?php if ($title): ?>
	            <div id="site-name"<?php if ($disable_site_name) { print ' class="hidden"'; } ?>>
		            <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home"><span><?php print $site_name; ?></span></a>
		          </div>
	          <?php else: ?>
		          <h1 id="site-name"<?php if ($disable_site_name) { print ' class="hidden"'; } ?>>
		            <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home"><span><?php print $site_name; ?></span></a>
		          </h1>
	          <?php endif; ?>
	        <?php endif; ?>
	        <?php if ($site_slogan): ?>
	          <div id="site-slogan"<?php if ( ($disable_site_slogan ) ) { print ' class="hidden"'; } if ( (!$disable_site_slogan ) AND ($disable_site_name) ) { print ' class="slogan-no-name"'; } ?>>
	            <?php print $site_slogan; ?>
	          </div>
	        <?php endif; ?>
        </div>
	    <?php endif; ?>
      <div class="row">
        <div class="span12">
          <div id="header">
            <?php print render($page['header']); ?>
          </div>
        </div>
      </div>
    </div>
	</header>
	<div role="main" class="main">
	  <div id="content" class="content full">
	    <div class="container">
        <?php if( ($page['before_content']) ): ?>
          <div class="row">
            <div class="span12">
              <?php print render($page['before_content']); ?>
            </div>
          </div>
        <?php endif;?>
        <div class="row">
					<div class="<?php if ( ($page['sidebar_right']) ) {  echo "span10"; }  else { echo "span12"; } ?> content-left">
					  <?php print $messages; ?>
			      <?php print render($page['help']); ?>
			      <?php if ($action_links): ?>
			        <ul class="action-links">
			          <?php print render($action_links); ?>
			        </ul>
			      <?php endif; ?>
					  <?php if (isset($page['content'])) { print render($page['content']); } ?>
					</div>
				  <?php if ( ($page['sidebar_right']) ) :?>
            <div class="span2 content-right">
              <?php print render($page['sidebar_right']); ?>
            </div>
				  <?php endif; ?>
        </div>
        <?php if( ($page['after_content']) ): ?>
          <div class="row">
            <div class="span12">
              <?php print render($page['after_content']); ?>
            </div>
          </div>
        <?php endif;?>
	    </div>
	  </div>
	</div>
  <div id="footer">
    <div class="container">
      <div class="row">
        <div class="span12">
          <?php print render($page['footer']); ?>
        </div>
      </div>
    </div>
  </div>
  <footer>
    <div class="container">
      <div class="row">
        <div class="span3">
          <?php if (isset($page['footer_1'])) : ?>
            <?php print render($page['footer_1']); ?>
          <?php endif; ?>
        </div>
        <div class="span3">
          <?php if (isset($page['footer_2'])) : ?>
            <?php print render($page['footer_2']); ?>
          <?php endif; ?>
        </div>
        <div class="span4">
          <?php if (isset($page['footer_3'])) : ?>
            <?php print render($page['footer_3']); ?>
          <?php endif; ?>
        </div>
        <div class="span2">
          <?php if (isset($page['footer_4'])) : ?>
            <?php print render($page['footer_4']); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
        <div class="row">
          <div class="span6">
            <?php if (isset($page['footer_bottom_left'])) : ?>
              <?php print render($page['footer_bottom_left']); ?>
            <?php endif; ?>
          </div>
          <div class="span6">
            <?php if (isset($page['footer_bottom_right'])) : ?>
              <?php print render($page['footer_bottom_right']); ?>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </footer>
</div>