<?php if ($rows) : ?>
  <div class="container">
    <div class="row" id="video-playlist">
      <div class="span10">
        <?php if ($header): ?>
          <?php print $header; ?>
        <?php endif; ?>
        <div class="row">
          <div class="view-video-playlist flexslider-top-title flexslider-center-mobile unstyled" data-plugin-options='{"directionNav": true, "controlNav": false, "slideshow": false, "animationLoop": true, "animation":"slide", "maxVisibleItems": 4}'">
            <ul class="slides">
              <?php print render($title_prefix); ?>
              <?php print render($title_suffix); ?>
              <?php if ($exposed): ?>
                <div class="view-filters"><?php print $exposed; ?></div>
              <?php endif; ?>
              <?php if ($attachment_before): ?>
                <div class="attachment attachment-before">
                  <?php print $attachment_before; ?>
                </div>
              <?php endif; ?>
              <?php print $rows; ?>
              <?php if (isset($empty) && $empty != FALSE): ?>
                <div class="view-empty"><?php print $empty; ?></div>
              <?php endif; ?>
              <?php if ($pager): ?>
                <?php print $pager; ?>
              <?php endif; ?>
              <?php if ($attachment_after): ?>
                <div class="attachment attachment-after">
                  <?php print $attachment_after; ?>
                </div>
              <?php endif; ?>
              <?php if ($more): ?>
                <?php print $more; ?>
              <?php endif; ?>
              <?php if ($footer): ?>
                <div class="view-footer"><?php print $footer; ?></div>
              <?php endif; ?>
              <?php if ($feed_icon): ?>
                <div class="feed-icon"><?php print $feed_icon; ?></div>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>