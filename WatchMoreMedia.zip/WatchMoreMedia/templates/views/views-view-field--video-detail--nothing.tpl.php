<?php

/**
 * @file
 * This template is used to print a single field in a view.
 *
 * It is not actually used in default Views, as this is registered as a theme
 * function which has better performance. For single overrides, the template is
 * perfectly okay.
 *
 * Variables available:
 * - $view: The view object
 * - $field: The field handler object that can process the input
 * - $row: The raw SQL result that can be used
 * - $output: The processed output that will normally be used.
 *
 * When fetching output from the $row, this construct should be used:
 * $data = $row->{$field->field_alias}
 *
 * The above will guarantee that you'll always get the correct data,
 * regardless of any changes in the aliasing that might happen if
 * the view is modified.
 */
?>
<?php
$html = '';
if (!empty($row)):
  $html .= '<div class="tabs-wrapper">';
  $html .= '<div class="tab-buttons">';

  $html .= '<ul>';
  $html .= '<li class="active"><span>' . t('INFO') . '</span></li>';
  $html .= '<li><span>' . t('SHARE') . '</span></li>';
  $html .= '<li><span>' . t('Credits') . '</span></li>';
  $html .= '</ul>';
  $html .= '</div>';
  $html .= '<div class="tab-container">';

  $html .= '<div class="tab-content active">';
  if (!empty($row->node_created)):
    $html .= '<p><strong>' . t('Published') . ' '.render(date('M d, Y', $row->node_created))  . '</strong> '. '</p>';
  endif;
  $html .= '<div class="description">';
  $html .= '<strong>'.t('Video Description').': </strong>'.render($row->field_body);
  $html .= '<ul class="list-other-info">';
  if(!empty($row->node_counter_totalcount)):
  $html .= '<li><strong>'.t('Views').': </strong>' . render($row->node_counter_totalcount) . '</li>';
  endif;
  if(!empty($row->field_field_rating)):
  $html .= '<li><strong>'.t('Rating').': </strong>' . render($row->field_field_rating) . '</li>';
  endif;
  if(!empty($row->field_field_categories[0]['raw'])):
  $html .= '<li><strong>'.t('Category').': </strong>' . render($row->field_field_categories[0]['raw']['taxonomy_term']->name) . '</li>';
  endif;
  if($row->field_field_keyword):
  $html .= '<li><strong>'.t('Keywords').': </strong>' . render($row->field_field_keyword) . '</li>';
  endif;
  $html .= '</ul>';
  $html .= '</div>';

  $html .= '</div>';
  $html .= '<div class="tab-content hid">';
  if (!empty($row->field_field_addthis)):
    $html .= render($row->field_field_addthis);
  endif;
  $html .= '<input id="share_url" value="' . $GLOBALS['base_url'] . url('node/' . $row->nid) . '" name="share_url" onClick="this.select();">';
  $html .= '</div>';

  $html .= '<div class="tab-content hid">';
  if(!empty($row->field_field_credit)):
  $html .= '<p><strong>' . t('Video Credit: ') .'</strong>'. render($row->field_field_credit) . '</p>';
  endif;
  $html .= '</div>';

  $html .= '</div>';
  $html .= '</div>';
endif;
print $html;
?>
<?php
print '<div class="like-favorite-block">';
$widget_id = '1';
print rate_generate_widget($widget_id, 'node', $row->nid);
global $user;
if (!$user->uid) :
  print '<span class="flag-wrapper">' . l(t('Add to favorites'), 'user/login') . '</span>';
else:
  print flag_create_link('video_favorites', $row->nid);
endif;
print '</div>';
?>