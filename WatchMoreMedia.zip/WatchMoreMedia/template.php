<?php

// 29 is id of the ads block in header
define('ID_ADS_BLOCK', 29);

/**
 * Overwrite theme_button()
 * @file template.php
 */
function WatchMoreMedia_button($variables) {
  $element = $variables['element'];
  $element['#attributes']['type'] = 'submit';
  element_set_attributes($element, array('id', 'name', 'value'));

  $element['#attributes']['class'][] = 'form-' . $element['#button_type'];
  if (!empty($element['#attributes']['disabled'])) {
    $element['#attributes']['class'][] = 'form-button-disabled';
  }
  $arr = in_array('watchmoremediaBtn', $element['#attributes']['class']);
  if (!empty($arr)) {
    if ($rem_id = array_search('form-submit', $element['#attributes']['class'])) {
      unset($element['#attributes']['class'][$rem_id]);
    }
    $caption = $element['#attributes']['value'];
    $element['#attributes']['value'] = str_replace('edit-', '', $element['#id']);
    return '<button' . drupal_attributes($element['#attributes']) . ' >' . $caption . '</button>';
  }
  else {
    $element['#attributes']['class'][] = 'btn-primary btn';
  }

  return '<input' . drupal_attributes($element['#attributes']) . ' />';
}

/**
 * Processes variables for node.tpl.php
 *
 * Most themes utilize their own copy of node.tpl.php. The default is located
 * inside "modules/node/node.tpl.php". Look in there for the full list of
 * variables.
 *
 * The $variables array contains the following arguments:
 * - $node
 * - $view_mode
 * - $page
 *
 * @see node.tpl.php
 */
function WatchMoreMedia_preprocess_node(&$variables) {
  switch ($variables['type']) {
    case 'video':
      $listView = statistics_get($variables['nid']);
      $variables['content']['views'] = array(
        '#type' => 'markup',
        '#weight' => 1,
        '#markup' => !empty($listView['totalcount']) ? "<div class=\"field\"><div class=\"field-label\">" . t('Views') . ":&nbsp;</div><div class=\"field-items\">
          <div class=\"field-item even\">" . $listView['totalcount'] . "</div></div></div>" : '',
      );
      $variables['content']['favorites'] = array(
        '#type' => 'markup',
        '#weight' => 1,
        '#markup' => flag_create_link('video_favorites', $variables['nid']),
      );
      $variables['content']['view_detail'] = array(
        '#type' => 'markup',
        '#weight' => 1,
        '#markup' => views_embed_view('video', 'video_playlist'),
      );

      $fcid = isset($variables['field_content'][0]['value']) ?
          $variables['field_content'][0]['value'] : 0;
      $media_content_data = field_collection_item_load($fcid);
      if (isset($media_content_data->field_url) && $media_content_data->field_url) {
        $url = field_get_items('field_collection_item', $media_content_data, 'field_url');
        $video_url = !empty($url[0]['value']) ? $url[0]['value'] : FALSE;
        $video_type = isset($variables['content']['field_type'][0]) ?
            trim(render($variables['content']['field_type'][0])) : '';
        if ($video_url != FALSE) {
          $variables['video'] = "<div class='flowplayer no-toggle'><video autoplay>";
          $variables['video'] .= "<source type='$video_type' src='$video_url' />";
          $variables['video'] .= "</video></div>";
        }
      }
      elseif (isset($variables['content']['field_player'][0])) {
        $player = render($variables['content']['field_player'][0]);
        if ($player != FALSE) {
          $variables['video'] = "<object width='100%' height='420'>
                       <param name='movie' value='$player'/>
                       <param name='wmode' value='transparent' />
                       <param name='allowFullScreen' value='true'/>
                       <param name='allowscriptaccess' value='always'/>
                       <embed src='$player'
                         type='application/x-shockwave-flash' wmode='transparent'
                         allowscriptaccess='always' allowfullscreen='true'
                         width='100%' height='420'/>
                    </object>";
        }
      }
      elseif (isset($variables['content']['field_embed']) && $variables['content']['field_embed']) {
        $variables['video'] = render($variables['content']['field_embed']);
      }
      break;

    case 'distributor':
      // if location module exist in system, we can override theme location by a custom theme
      if (isset($variables['content']['field_distributor_location']) && module_exists('location')) {
        // override theme of location in distributor node
        $elements = element_children($variables['content']['field_distributor_location']);
        foreach ($elements as $element) {
          $variables['content']['field_distributor_location'][$element]['#theme'] = 'custom_location';
        }
      }
      break;
    case 'show':
      break;
    default:
      break;
  };
}

/**
 * Add CSS and JS for flowplayer
 * Implements hook_preprocess_html
 */
function WatchMoreMedia_preprocess_html(&$variables) {
  $flowplayer_css = array(
    '#tag' => 'link',
    '#attributes' => array(
      'href' => '//releases.flowplayer.org/5.4.4/skin/minimalist.css',
      'rel' => 'stylesheet',
      'type' => 'text/css',
    ),
    '#weight' => 900,
  );
  drupal_add_html_head($flowplayer_css, 'flowplayer_css');
  drupal_add_js('//releases.flowplayer.org/5.4.4/flowplayer.min.js', 'external');
}

/**
 * Implements hook_preprocess_page
 */
function WatchMoreMedia_preprocess_page(&$vars) {
  $block_ads = module_invoke('block', 'block_view', ID_ADS_BLOCK);
  if (!empty($block_ads['content'])) {
    $vars['block_ads'] = render($block_ads['content']);
  }
  else {
    $vars['block_ads'] = '';
  }
  // Page node show
  if ((isset($vars['node']) && $vars['node']->type == 'show') ||
      (arg(0) == 'shows' && is_numeric(arg(1)))) {
    $node = node_load(arg(1));
    $vars['menu_show'] = theme('menu_show', array('node' => $node));
  }
  
  //Load the nodequeue - 4 is the ID of Video Playlist	  
  $nodequeue = nodequeue_view_nodes(4);
  
  //Get the count of the current nodequeue
  $sql = "SELECT COUNT(nid) FROM {nodequeue_nodes} WHERE qid = 4";
  $nodequeue_count = db_query($sql)->fetchField();
  
  // Get all the nodequeue URL and put in an array
  $node_link_array = array(); 
   
  for ($x = 0; $x < $nodequeue_count; $x++) {
  	  
	  // Get the Node ID then get the URL alias
	  $nid = $nodequeue[$x]['#node']->nid;
	  $alias =  drupal_get_path_alias('node/'.$nid);
	  $node_link_array[] = $alias;
	  
  }
 
  // Get current URL to check which video is playing
  $current_path = current_path();
  
  //Get count of nodequeue
  $array_count = count($node_link_array);
  
  if($current_path == 'node'){
  	// We are in home page, get the last video in the array
  	$last_video = $array_count - 1;
	  $next_video  = $last_video;

  }
  else{
  	//Get the current URL and check the index
	$current_alias = drupal_get_path_alias();
	$key = array_search($current_alias, $node_link_array);
  // dpm($key);  
	$next_video = $key - 1;
  // dpm($next_video);
  if ( $next_video == -1) {
      $last_video = $array_count -1;
      $next_video = $last_video;
    }

  }
  
  drupal_add_js(array('WatchMoreMedia' => array('node_link_array' => $node_link_array, 'nodequeue_count' => $nodequeue_count, 'next_video' => $next_video)), array('type' => 'setting'));


  
}

/**
 * Implements hook_theme
 */
function WatchMoreMedia_theme() {
  return array(
    'menu_show' => array(
      'variables' => array('node' => NULL),
      'function' => 'custom_menu_show',
    ),
    'custom_location' => array(
      'template' => 'templates/theme_custom/custom-location',
      'variables' => array(
        'location' => NULL,
        'hide' => array(),
      ),
    ),
  );
}

/**
 * Theme preprocess function for a location (custom template location).
 */
function WatchMoreMedia_preprocess_custom_location(&$variables) {
  if (module_exists('location')) {
    $location = $variables['location'];
    // This will get taken back out if map links are hidden.
    $location['map_link'] = TRUE;
    if (is_array($variables['hide'])) {
      foreach ($variables['hide'] as $key) {
        unset($location[$key]);
        // Special case for coords.
        if ($key == 'coords') {
          unset($location['latitude']);
          unset($location['longitude']);
        }
      }
    }

    $fields = location_field_names(TRUE);
    if (is_array($fields)) {
      foreach ($fields as $key => $value) {
        $variables[$key] = '';
        // Arrays can't be converted, ignore them.
        if (!empty($location[$key]) && !is_array($location[$key])) {
          $variables[$key] = check_plain($location[$key]);
          $arr_key = array(
            'street' => t('Address 1'),
            'additional' => t('Address 2'),
          );
          if (array_key_exists($key, $arr_key)) {
            $variables[$key . '_label'] = $arr_key[$key];
          }
          else {
            $variables[$key . '_label'] = $value;
          }
        }
      }
    }

    // Map link.
    $variables['map_link'] = '';
    if (!empty($location['map_link'])) {
      // Do not use $location for generating the map link, since it will
      // not contain the country if that field is hidden.
      $variables['map_link'] = location_map_link($variables['location']);
    }

    // Theme latitude and longitude as d/m/s.
    $variables['latitude'] = '';
    $variables['latitude_dms'] = '';
    if (!empty($location['latitude'])) {
      $variables['latitude'] = check_plain($location['latitude']);
      $variables['latitude_dms'] = theme('location_latitude_dms', array('latitude' => $location['latitude']));
    }

    $variables['longitude'] = '';
    $variables['longitude_dms'] = '';
    if (!empty($location['longitude'])) {
      $variables['longitude'] = check_plain($location['longitude']);
      $variables['longitude_dms'] = theme('location_longitude_dms', array('longitude' => $location['longitude']));
    }

    // Add a country-specific template suggestion.
    if (!empty($location['country']) && location_standardize_country_code($location['country'])) {
      // $location['country'] is normalized in the previous line.
      $variables['theme_hook_suggestions'][] = 'location__' . $location['country'];
    }

    // Display either the code or the full name for the province.
    if (!isset($location['province'])) {
      $location['province'] = '';
    }
    if (!isset($location['province_name'])) {
      $location['province_name'] = '';
    }
    $variables['province_print'] = variable_get('location_use_province_abbreviation', 1) ? $location['province'] : $location['province_name'];
  }
}

function custom_menu_show($vars) {
  if (module_exists('watchmoremedia_alias')) {
    $node = $vars['node'];
    // constants is defined in watchmoremedia_alias module
    $alias_cast = drupal_get_path_alias("shows/$node->nid/" . CAST);
    $alias_gallery = drupal_get_path_alias("shows/$node->nid/photos-gallery");
    $alias_episodes = drupal_get_path_alias("shows/$node->nid/" . EPISODES);
    $classNoImage = empty($node->field_tvshow_poster) ? 'no-image' : '';
    $block = "<div class='menu-shows $classNoImage'>";
    $block .= "<div class='wrap-poster'>";
    $block .= "<div class='shows-title'>";
    $block .= "<a href='/" . drupal_get_path_alias('node/' . $node->nid) . "'>" . $node->title . '</a>';
    $block .= "</div>";
    if (!empty($node->field_tvshow_poster)) {
      $block .= "<div class='poster'>";
      $field_poster = field_get_items('node', $node, 'field_tvshow_poster');
      $poster_url = file_create_url($field_poster[0]['uri']);
      $block .= "<img src=$poster_url / alt='$node->title' title='$node->title'>";
      $block .= "</div>";
    }
    $block .= "</div>"; // close tag of 'wrap-poster'
    $block .= "<ul class='shows'>";
    $block .= "<li> <a href='/" . $alias_cast . "'>" . t("Cast") . "</a></li>";
    $block .= "<li> <a href='/" . $alias_gallery . "'>" . t("Gallery") . "</a></li>";
    $block .= "<li> <a href='/" . $alias_episodes . "'>" . t("Episodes") . "</a></li>";
    $block .= "</ul>";
    $block .= '</div>';
  }
  return isset($block) ? $block : '';
}

/**
 * Override theme_item_list
 */
function WatchMoreMedia_item_list($vars) {
  if (isset($vars['attributes']['class']) && in_array('pager', $vars['attributes']['class'])) {
    foreach ($vars['items'] as $i => &$item) {
      if (in_array('pager-current', $item['class'])) {
        $item['class'] = array('active');
        $item['data'] = '<a href="#">' . $item['data'] . '</a>';
      }
      elseif (in_array('pager-ellipsis', $item['class'])) {
        $item['class'] = array('disabled');
        $item['data'] = '<a href="#">' . $item['data'] . '</a>';
      }
    }
    return '<div class="pagination pagination-large pull-right">' . theme_item_list($vars) . '</div>';
  }
  return theme_item_list($vars);
}
