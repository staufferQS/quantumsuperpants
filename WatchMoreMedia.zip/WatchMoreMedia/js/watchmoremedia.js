/**
 * @file
 * A JavaScript file for the theme.
 *
 */
(function ($) {


  Drupal.behaviors.WatchMoreMedia = {
    attach: function (context, settings) {
	
        Drupal.settings.WatchMoreMedia = Drupal.settings.WatchMoreMedia || {};    	
	var node_link_array = Drupal.settings.WatchMoreMedia.node_link_array;
	var nodequeue_count = Drupal.settings.WatchMoreMedia.nodequeue_count;    
    var next_video = Drupal.settings.WatchMoreMedia.next_video;  
if (typeof flowplayer !== "function") return; 
	  // Flowplayer
	  flowplayer(function (api, root) {
	      
		  api.bind("finish", function () {
		  
		  if(node_link_array[next_video] != undefined){
		  	window.location.replace("/" + node_link_array[next_video]);
		  }

		  })
	 
	  });
	
	
    }
  };
  


})(jQuery);








