/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Website start here
 */
jQuery(document).ready(function($) {
  // Render document

  // Mobile Menu
  $('header .region-header').mobileMenu();

  //Using Flex Slider Counter plugin
  $('#video-playlist').smFlexSliderCounter({
    flexsliderSelector: '.view-video-playlist',
    counterSelector:    '.number-item',
    sliderSelector:     '.slides',
    groupItemSelector:  'li:not(.clone)',
    activeSelector:     '.flex-active-slide',
    itemSelector:       '.views-row',
    buttonNextSelector: '.flex-next',
    buttonPrevSelector: '.flex-prev',
    unitText:           'videos'
  });

  /* Using Tab Switch plugin */
  $('.tabs-wrapper').smTabSwitch({
    buttonHolderSelector: '.tab-buttons',
    buttonSelector: 'li',
    contentHolderSelector: '.tab-container',
    contentSelector: '.tab-content',
    activeClass: 'active',
    hiddenClass: 'hid',
    duration: 300,
    endCallBack: function(){}
  });


});