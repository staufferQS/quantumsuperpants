/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @name smFlexSliderCounter
 * @description description
 * @version 1.0
 * @options
 *    counterSelector
 *    sliderSelector
 *    groupItemSelector
 *    activeSelector
 *    itemSelector
 *    buttonNextSelector
 *    buttonPrevSelector
 *    unitText
 * @events
 *    onButtonClick
 * @methods
 *    init
 *    checkIndex
 *    destroy
 */
;(function($, window, undefined) {
  var pluginName = 'smFlexSliderCounter';

  function Plugin(element, options) {
    this.element = $(element);
    this.options = $.extend({}, $.fn[pluginName].defaults, options);
    this.init();
  };

  Plugin.prototype = {
    init: function() {
      var there   = this,
          element = this.element,
          options = this.options;

      var slider = element.find(options.flexsliderSelector);
      var defaults = {
        animationLoop: false,
        controlNav: true,
        directionNav: true
      }

      var config = $.extend({}, defaults, slider.data("plugin-options"));

      if(($(window).width() < 768 && slider.hasClass("normal-device")) || $(window).width() > 768 && slider.hasClass("small-device") || (!slider.hasClass("flexslider-init"))) {
        // Reset if already initialized.
        if(slider.find("div.flex-viewport") && typeof(config.maxVisibleItems) != "undefined") {

          var el = slider;

          el.find("li.clone").remove();

          var elClean = el.clone();

          elClean.find("div.flex-viewport").children().unwrap();

          elClean
            .find("ul.flex-direction-nav, ol.flex-control-nav")
            .remove()
            .end()
            .find("*").removeAttr("style").removeClass (function (index, css) {
              return (css.match (/\bflex\S+/g) || []).join(" ");
            });

          elClean.insertBefore(el);

          el.remove();

          slider = elClean;
        }

        // Set max visible items.
        if(typeof(config.maxVisibleItems) != "undefined") {
          slider.find("ul.slides li > div").unwrap();

          var items = slider.find("ul.slides").children("div");
          var visibleItems = config.maxVisibleItems;

          if($(window).width() < 768) {
            //visibleItems = 1;
            slider
              .removeClass("normal-device")
              .addClass("small-device");
          } else {
            slider
              .removeClass("small-device")
              .addClass("normal-device");
          }
          for (var i = 0; i < items.length; i+= visibleItems) {
            var slice = items.slice(i,i + visibleItems);
            slice.wrapAll("<li></li>");
          }
        }
      }

      config.after = function(){there.checkIndex()};
      config.keyboard = false;
      // Initialize Slider
      slider.flexslider(config).addClass("flexslider-init");

      if(config.controlNav)
        slider.addClass("flexslider-control-nav");

      if(config.directionNav)
        slider.addClass("flexslider-direction-nav");

      this.vars = {
        counter: element.find(options.counterSelector),
        slider: element.find(options.sliderSelector),
        buttonNext: element.find(options.buttonNextSelector),
        buttonPrev: element.find(options.buttonPrevSelector)
      };

      var vars = this.vars;
      vars.groupItems    = vars.slider.find(options.groupItemSelector),
      vars.items         = vars.groupItems.find(options.itemSelector);
      vars.groupCount    = vars.groupItems.length;
      vars.itemCount     = vars.items.length;
      vars.countPerGroup = vars.groupItems.first().find(options.itemSelector).length;

      this.checkIndex();

      //vars.flex.data('flexslider').setOpts({after: function(){alert(1)}});

      this.vars.buttonNext.bind('click.' + pluginName, function(){
        there.checkIndex();
      });

      this.vars.buttonPrev.bind('click.' + pluginName, function(){
        there.checkIndex();
      });


    },
    checkIndex: function() {
      var vars       = this.vars,
          options    = this.options,
          activeItem = vars.slider.find(options.activeSelector),
          index      = vars.groupItems.index(activeItem),
          count      = (index + 1) * vars.countPerGroup;

      if(count > vars.itemCount) count = vars.itemCount;

      vars.counter.text(count + '/' + vars.itemCount + ' ' + options.unitText);
    },
    destroy: function() {
      $.removeData(this.element[0], pluginName);
    }
  };

  $.fn[pluginName] = function(options, params) {
    return this.each(function() {
      var instance = $.data(this, pluginName);
      if (!instance) {
        $.data(this, pluginName, new Plugin(this, options));
      } else if (instance[options]) {
        instance[options](params);
      } else {
        console.warn(options ? options + ' method is not exists in ' + pluginName : pluginName + ' plugin has been initialized');
      }
    });
  };

  $.fn[pluginName].defaults = {
    flexsliderSelector: '.view-video-playlist',
    counterSelector:    '.number-item',
    sliderSelector:     '.slides',
    groupItemSelector:  'li:not(.clone)',
    activeSelector:     '.flex-active-slide',
    itemSelector:       '.views-row',
    buttonNextSelector: '.flex-next',
    buttonPrevSelector: '.flex-prev',
    unitText:           'videos'
  };
}(jQuery, window));

/**
 * @name smTabSwitch
 * @description description
 * @version 1.0
 * @options
 *    option
 * @events
 *    event
 * @methods
 *    init
 *    publicMethod
 *    destroy
 */
;(function($, window, undefined) {
  var pluginName = 'smTabSwitch';
  var document = window.document;

  function Plugin(element, options) {
    this.element = $(element);
    this.options = $.extend({}, $.fn[pluginName].defaults, options);
    this.init();
  };

  Plugin.prototype = {
    init: function() {
      var there = this;
      var options = this.options;
      var elements = this.element;
      var contentHolder = elements.find(options.contentHolderSelector);
      var contents = contentHolder.find(options.contentSelector);
      var buttonHolder = elements.find(options.buttonHolderSelector);
      var buttons = buttonHolder.find(options.buttonSelector);

      this.vars = {
        wrapper: elements,
        contentHolder: contentHolder,
        contents: contents,
        numberOfContent: contents.length > buttons.length ? buttons.length : contents.length,
        contentHieght: [],
        current: 0,
        buttons: buttons,
        isJump: false,
        navigation: 1     // 0: left to right; 1 right to left
      };

      var vars = this.vars;

      vars.maxWidth = elements.innerWidth();
      vars.extraHeight = buttonHolder.outerHeight(true) + parseInt(contentHolder.css('padding-top')) + 10;
      
      $.each(vars.contents, function(index, child){
        if(buttons[index]){
          $(this).css({
            'position': 'absolute',
            'max-width': vars.maxWidth
          });
          if(index > 0){
            $(this).css({
              'opacity': '0'
            });
          } else {
            $(this).addClass(options.activeClass);
            $(buttons[index]).addClass(options.activeClass);
            vars.wrapper.css('height', $(this).outerHeight() + vars.extraHeight);
          }
          $.data(buttons[index], 'index', index);
        }
      });
      
      buttons.unbind('click.' + pluginName).bind('click.' + pluginName, function(){
        if(vars.isJump == false){
          vars.isJump = true;
          var jumpToIndex = $.data(this, 'index');
          if(jumpToIndex > vars.current){
            vars.navigation = 1;
          }
          else {
            vars.navigation = 0;
          }
          there.jumpTo(jumpToIndex, options.endCallBack);
        }
      });
      $(window).bind('resize.' + pluginName, function(){
        there.reposition();
      });
    },
    jumpTo: function(index, callback) {
      if(index > -1 && index < this.vars.numberOfContent
                    && index != this.vars.current){
        var there = this;
        var vars = this.vars;
        var options = this.options;
        var outItem = $(this.vars.contents[this.vars.current]);
        var inItem = $(this.vars.contents[index]);
        var outSelector = $(this.vars.buttons[this.vars.current]);
        var inSelector = $(this.vars.buttons[index]);
        var inWidth = inItem.outerHeight() + vars.extraHeight;
        var outWidth = vars.wrapper.outerHeight();

        vars.wrapper.animate({
          'height': inWidth
        }, options.duration);

        outItem.removeClass(options.activeClass);
        outSelector.removeClass(options.activeClass);
        inItem.removeClass(options.hiddenClass);

        inItem.animate({
          'opacity': 1
        }, options.duration, function(){
          vars.isJump = false;
          inItem.addClass(options.activeClass);
          inSelector.addClass(options.activeClass);
          outItem.css('opacity', 0);

          if($.isFunction(callback)){ 
            callback.call(this);
          };
        });
        
        outItem.animate({
          'opacity': 0,
        }, options.duration, function(){
          $(this).addClass(options.hiddenClass);
        });
        
        vars.current = index;
      }
      else {
        this.vars.isJump = false;
      }
    },
    reposition: function(){
      var vars = this.vars;
      var options = this.options;
      vars.maxWidth = vars.wrapper.innerWidth();
      $.each(vars.contents, function(index, child){
        if(vars.buttons[index]){
          $(this).css({
            'max-width': vars.maxWidth
          });
        }

        if($(this).hasClass(options.activeClass)){
          vars.wrapper.css('height', $(this).outerHeight() + vars.extraHeight);
        }
      });
    },
    destroy: function() {
      $.removeData(this.element[0], pluginName);
    }
  };

  $.fn[pluginName] = function(options, params) {
    return this.each(function() {
      var instance = $.data(this, pluginName);
      if (!instance) {
        $.data(this, pluginName, new Plugin(this, options));
      } else if (instance[options]) {
        instance[options](params);
      } else {
        console.warn(options ? options + ' method is not exists in ' + pluginName : pluginName + ' plugin has been initialized');
      }
    });
  };

  $.fn[pluginName].defaults = {
    buttonHolderSelector: '.tab-buttons',
    buttonSelector: 'li',
    contentHolderSelector: '.tab-container',
    contentSelector: '.tab-content',
    activeClass: 'active',
    hiddenClass: 'hid',
    duration: 500,
    endCallBack: function(){}
  };
}(jQuery, window));