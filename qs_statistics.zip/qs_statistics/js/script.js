(function($) {
    Drupal.behaviors.watchmoremedia_statistics = {
        'attach': function(context, settings) {
            $("#edit-submit-statistics-video", context).click(function() {
                // write code here
                var elements = [
                'edit-date-filter-min-month',
                'edit-date-filter-min-day',
                'edit-date-filter-min-year',
                'edit-date-filter-max-month',
                'edit-date-filter-max-day',
                'edit-date-filter-max-year'
                ];
                for(var i = 0; i < elements.length; i++) {
                    if(!checkSelected(elements[i])) return false;
                }
                function checkSelected(els) {
                    var elsObj = $('#' + els);
                    if(elsObj.val().trim() === "") {
                        elsObj.focus();
                        alert('Please select all text information');
                        return false;
                    }
                    return true;
                }
            });
        }
    };
})(jQuery);

